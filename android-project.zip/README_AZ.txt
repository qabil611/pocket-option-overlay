POCKET OPTION OVERLAY — ilkin Android layihəsi

Bu paket hazır ticarət skaneri deyil. Məqsəd Android-də başqa tətbiqin üzərində üzən panel göstərmək və istifadəçinin icazəsi ilə ekranı tutmaq üçün işlək başlanğıc layihə verməkdir.
Bu versiya hələ şamları tanımır, BUY/SELL siqnalı hesablamır və əməliyyat açmır.

APK yaratmaq üçün:
1) GitHub-da boş repository yaradın.
2) Bu paketdən android-project.zip faylını repository-nin əsas qovluğuna yükləyin.
3) Eyni əsas qovluğa .github/workflows/build.yml faylını ayrıca yükləyin (bu arxivdə ayrıca verilir).
4) GitHub → Actions bölməsinə keçin. "Build Android APK" workflow-unu açıb Run workflow basın.
5) İş bitəndə workflow run səhifəsinin aşağısında Artifacts bölməsindən pocket-overlay-debug-apk faylını endirin.
6) ZIP-i telefonda açın, app-debug.apk faylını quraşdırın. Android naməlum mənbədən quraşdırma icazəsi istəyə bilər.
7) Tətbiqi açın, Overlay icazəsini aktiv edin, sonra ekran paylaşımı icazəsini təsdiqləyin.
8) Pocket Option tətbiqinə keçəndə üzən panel görünməlidir.

Vacib:
- Ekran tutma icazəsi Android-in öz pəncərəsi ilə hər dəfə istifadəçi tərəfindən verilir.
- Bəzi bank/DRM ekranları Android tərəfindən qara göstərilə bilər.
- Bu texniki skeletin üzərinə növbəti mərhələdə qrafik sahəsinin seçilməsi, şamların piksel analizi, trend/indikator hesablanması və vizual BUY/SELL oxları əlavə edilməlidir.
- Siqnallar zəmanət deyil. OTC qrafikinin şamları xarici Binance/Twelve Data qiymətləri ilə eyni olmaya bilər.
